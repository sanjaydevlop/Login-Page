from django.apps import AppConfig


class ManempConfig(AppConfig):
    name = 'manemp'
