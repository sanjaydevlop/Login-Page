from django import forms  
from .models import Employee,Department,Manager 
class EmployeeForm(forms.ModelForm):  
    class Meta:  
        model = Employee  
        fields = "__all__"

class ManagerForm(forms.ModelForm):
    class Meta:
        model=Manager
        fields="__all__"
class DepartmentForm(forms.ModelForm):
    class Meta:
        model=Department
        fields ="__all__"





     