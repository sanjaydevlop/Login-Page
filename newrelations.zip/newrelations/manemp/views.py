from django.shortcuts import render, redirect  
from manemp.forms import EmployeeForm,ManagerForm,DepartmentForm
from manemp.models import Employee,Department,Manager
def demp(request):  
    if request.method == "POST":  
        form = DepartmentForm(request.POST)  
        if form.is_valid():  
            try:  
                form.save()  
                return redirect('/dshow')  
            except:  
                pass  
    else:  
        form = DepartmentForm(request.POST)  
    return render(request,'dindex.html',{'form':form})
    
def dshow(request):  
    departments = Department.objects.all()  
    return render(request,"dshow.html",{'departments':departments})  
def dedit(request, id):  
    department = Department.objects.get(dep_id=id)  
    return render(request,'dedit.html', {'department':department})  
def dupdate(request, id):  
    department = Department.objects.get(dep_id=id)  
    form = DepartmentForm(request.POST, instance = department)  
    if form.is_valid():  
        form.save()  
        return redirect("/dshow")  
    return render(request, 'dedit.html', {'department': department})  
def ddestroy(request, id):  
    department = Department.objects.get(dep_id=id)  
    department.delete()  
    return redirect("/dshow")

def memp(request):  
    if request.method == "POST":  
        form = ManagerForm(request.POST)  
        if form.is_valid():  
            try:  
                form.save()  
                return redirect('/mshow')  
            except:  
                pass  
    else:  
        form = ManagerForm(request.POST)  
    return render(request,'mindex.html',{'form':form})
    
def mshow(request):  
    managers = Manager.objects.all()  
    return render(request,"mshow.html",{'managers':managers})  
def medit(request, id):  
    manager = Manager.objects.get(man_id=id)  
    return render(request,'medit.html', {'manager':manager})  
def mupdate(request, id):  
    manager = Manager.objects.get(man_id=id)  
    form = ManagerForm(request.POST, instance = manager)  
    if form.is_valid():  
        form.save()  
        return redirect("/mshow")  
    return render(request, 'medit.html', {'manager': manager})  
def mdestroy(request, id):  
    manager = Manager.objects.get(man_id=id)  
    manager.delete()  
    return redirect("/mshow")

def emp(request):  
    if request.method == "POST":  
        form = EmployeeForm(request.POST)  
        if form.is_valid():  
            try:  
                form.save()  
                return redirect('/show')  
            except:  
                pass  
    else:  
        form = EmployeeForm(request.POST)  
    return render(request,'index.html',{'form':form})
    
def show(request):  
    employees = Employee.objects.all()  
    return render(request,"show.html",{'employees':employees})  
def edit(request, id):  
    employee = Employee.objects.get(emp_id=id)  
    return render(request,'edit.html', {'employee':employee})  
def update(request, id):  
    employee = Employee.objects.get(emp_id=id)  
    form = EmployeeForm(request.POST, instance = employee)  
    if form.is_valid():  
        form.save()  
        return redirect("/show")  
    return render(request, 'edit.html', {'employee': employee})  
def destroy(request, id):  
    employee = Employee.objects.get(emp_id=id)  
    employee.delete()  
    return redirect("/show")
def search(request):
    query=request.GET['query']  
    employees = Employee.objects.filter(emp_man_id__man_id__icontains=query)  
    return render(request,"search.html",{'employees':employees})

def searchman(request):
    query=request.GET['query']
    managers=Manager.objects.filter(man_dep_id__dep_id__icontains=query)
    return render(request,"searchman.html",{'managers':managers})

# def promote(request):
#     employee = Employee.objects.get(emp_id=id)  
#     return render(request,'medit.html', {'employee':employee})