from django.db import models

# Create your models here.

class Department(models.Model):
    dep_name=models.CharField(max_length=20)
    dep_id=models.CharField(max_length=20,primary_key=True)
    def __str__(self):
        return self.dep_id
class Manager(models.Model):
    man_name=models.CharField(max_length=20)
    man_id=models.CharField(max_length=20,primary_key=True)
    man_dep_id=models.ForeignKey(Department,on_delete=models.SET_NULL,null=True)
    def __str__(self):
        return self.man_id
class Employee(models.Model):
    emp_name=models.CharField(max_length=20)
    emp_id=models.CharField(max_length=20,primary_key=True)
    emp_contact=models.CharField(max_length=10)
    emp_man_id=models.ForeignKey(Manager,on_delete=models.SET_NULL,null=True)
    def __str__(self):
        return self.emp_id


