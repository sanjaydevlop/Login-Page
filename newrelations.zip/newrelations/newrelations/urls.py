"""newrelations URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/2.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from manemp import views
urlpatterns = [
    path('admin/', admin.site.urls),
    path('demp',views.demp),
    path('dshow',views.dshow),
    path('dedit/<str:id>',views.dedit),
    path('dupdate/<str:id>', views.dupdate),  
    path('ddelete/<str:id>', views.ddestroy),
    path('memp', views.memp),  
    path('mshow',views.mshow),  
    path('medit/<str:id>', views.medit),  
    path('mupdate/<str:id>', views.mupdate),  
    path('mdelete/<str:id>', views.mdestroy),
    path('emp', views.emp),  
    path('show',views.show),  
    path('edit/<str:id>', views.edit),  
    path('update/<str:id>', views.update),  
    path('delete/<str:id>', views.destroy),
    path('search/',views.search),
    path('searchman',views.searchman),
    # path('promote/',views.promote),

]
